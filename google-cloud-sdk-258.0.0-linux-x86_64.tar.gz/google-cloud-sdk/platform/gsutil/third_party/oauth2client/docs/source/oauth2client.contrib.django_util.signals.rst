oauth2client\.contrib\.django\_util\.signals module
===================================================

.. automodule:: oauth2client.contrib.django_util.signals
    :members:
    :undoc-members:
    :show-inheritance:
