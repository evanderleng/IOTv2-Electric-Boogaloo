
Go Externalized Runtime
=======================

This is the Go runtime definition that will soon be used by gcloud for
generating dockerfiles for GAE.
